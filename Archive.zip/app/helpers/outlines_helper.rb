module OutlinesHelper
end
