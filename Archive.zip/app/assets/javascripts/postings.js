// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.
  function dropDown1() {
                  document.getElementById("col1").classList.toggle("show");
                }
function dropDown1_1() {
                  document.getElementById("col2").classList.toggle("show");
                }
  function dropDown233() {
                  document.getElementById("myDropdown233").classList.toggle("show");
                }


                function dropDown144() {
                  document.getElementById("myDropdown144").classList.toggle("show");
                }
                function dropDown89() {
                  document.getElementById("myDropdown89").classList.toggle("show");
                }
                function dropDown55() {
                  document.getElementById("myDropdown55").classList.toggle("show");
                }

                function dropDown34() {
                  document.getElementById("myDropdown34").classList.toggle("show");

                }function dropDown21() {
                  document.getElementById("myDropdown21").classList.toggle("show");
                }
                function dropDown13() {
                  document.getElementById("myDropdown13").classList.toggle("show");
                }

                function dropDown8() {
                  document.getElementById("myDropdown8").classList.toggle("show");
                }  

                function dropDown5() {
                  document.getElementById("myDropdown5").classList.toggle("show");
                }

                function dropDown3() {
                  document.getElementById("myDropdown3").classList.toggle("show");
                }

                function dropDown2() {
                  document.getElementById("myDropdown2").classList.toggle("show");
                }   

                function dropDown1() {
                  document.getElementById("myDropdown1").classList.toggle("show");
                }
                