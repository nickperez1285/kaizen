require 'test_helper'

class RevTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
