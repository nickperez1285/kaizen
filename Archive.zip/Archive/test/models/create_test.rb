require 'test_helper'

class CreateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
