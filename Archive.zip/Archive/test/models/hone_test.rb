require 'test_helper'

class HoneTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
