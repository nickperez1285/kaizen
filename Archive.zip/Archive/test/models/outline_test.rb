require 'test_helper'

class OutlineTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
