require 'test_helper'

class BeginTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
