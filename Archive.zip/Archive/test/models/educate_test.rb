require 'test_helper'

class EducateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
