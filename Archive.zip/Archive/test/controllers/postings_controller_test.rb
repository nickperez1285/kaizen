require 'test_helper'

class PostingsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
