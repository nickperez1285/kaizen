require 'test_helper'

class LayOutsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
