require 'test_helper'

class OutlinesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
